#include <zlib.h>

#include "EvaluateUB.h"
#include "File.h"
//#include "Debug.h"
//#include "ADTs/Sort.h"

#define CHUNK_LIMIT 1048576

class WeightedClause {
public :
  vec<Lit> clause;
  int      weight;
  WeightedClause (vec<Lit>& c, int w) {
    c.copyTo(clause);
    weight = w; }
  bool operator <  (WeightedClause p) const { return weight < p.weight;  }
};


class StreamBuffer {
  gzFile  in;
  char    buf[CHUNK_LIMIT];
  int     pos;
  int     size;

  void assureLookahead() {
    if (pos >= size) {
      pos  = 0;
      size = gzread(in, buf, sizeof(buf)); } }

public:
  StreamBuffer(gzFile i) : in(i), pos(0), size(0) {
    assureLookahead(); }

  int  operator *  () { return (pos >= size) ? EOF : buf[pos]; }
  void operator ++ () { pos++; assureLookahead(); }
};

template<class B>
static void skipWhitespace(B& in) {
  while ((*in >= 9 && *in <= 13) || *in == 32)
    ++in; }

template<class B>
static void skipLine(B& in) {
  for (;;){
    if (*in == EOF || *in == '\0') return;
    if (*in == '\n') { ++in; return; }
    ++in; } }

template<class B>
static int parseInt(B& in) {
  int     val = 0;
  bool    neg = false;
  skipWhitespace(in);
  if      (*in == '-') neg = true, ++in;
  else if (*in == '+') ++in;
  if (*in < '0' || *in > '9') reportf("PARSE ERROR! Unexpected char: %c\n", *in), exit(3);
  while (*in >= '0' && *in <= '9')
    val = val*10 + (*in - '0'),
      ++in;
  return neg ? -val : val; }

template<class B>
static bool match(B& in, char* str) {
  for (; *str != 0; ++str, ++in)
    if (*str != *in)
      return false;
  return true;
}

template<class B>
static void readClause(B& in,int top, vec<WeightedClause*>& sc,vec<WeightedClause*>& hc) { // koshi 10.01.04

  int parsed_lit,var,weight;
  vec<Lit> clause;
  weight = parseInt(in);
    
  for (;;){
    parsed_lit = parseInt(in);
    if (parsed_lit == 0) break;
    var = abs(parsed_lit)-1;
    clause.push( (parsed_lit > 0) ? mkLit(var) : ~mkLit(var) );
  }
  if(weight != top) sc.push(new WeightedClause(clause,weight));
  else hc.push(new WeightedClause(clause,weight));
}


template<class B>
static void parse_WPMS_main(B& in,Solver& S,int& out_top, vec<WeightedClause*>& sc,vec<WeightedClause*>& hc) {
  for (;;){
    skipWhitespace(in);
    if (*in == EOF)
      break;
    else if (*in == 'p'){
      if (match(in, "p wcnf")){
	int vars    = parseInt(in);
	int clauses = parseInt(in);
	int top     = parseInt(in);
	out_top     = top;
	reportf("|  Number of variables:    %-12d                                       |\n", vars);
	reportf("|  Number of clauses:      %-12d                                       |\n", clauses);
	reportf("|  Top              :      %-12d                                       |\n", top);
	while (vars > S.nVars()) S.newVar();
      }else{
	reportf("PARSE ERROR! Unexpected char: %c\n", *in), exit(3);
      }
    } else if (*in == 'c' || *in == 'p')
      skipLine(in);
    else 
      readClause(in,out_top,sc,hc);
  }
}

static void parse_WPMS(gzFile input_stream, Solver& S,int& out_top,vec<WeightedClause*>& sc,vec<WeightedClause*>& hc) {
  StreamBuffer in(input_stream);
  parse_WPMS_main(in,S,out_top,sc,hc); }

// void dump_wc(vec<WeightedClause*>& wc){
//   for(int i; i<wc.size(); i++){
//     dump(wc[i]->clause); reportf(": %d  \n",wc[i]->weight);
//   }
// }

int eval_model(Solver S,vec<WeightedClause*>& sc)
{
  vec<lbool>& model = S.model();
  int eval=0;
  for(int i=0; i<sc.size(); i++){
    for(int j=0; j<sc[i]->clause.size(); j++){
      if(sign(sc[i]->clause[j]) && (model[var(sc[i]->clause[j])] == l_False)) {eval += sc[i]->weight;break;}
	else if(!sign(sc[i]->clause[j]) && (model[var(sc[i]->clause[j])] == l_True)) {eval += sc[i]->weight;break;}
      }
  }  
  return eval;
}

int evaluate_UB(cchar* input_file){
  int top,eval;
  Solver S = new Minisat2 ::Solver();//pb_solver.getSolver();
  gzFile in = gzopen(input_file, "rb");
  vec<WeightedClause*> sc,hc;

  reportf("estimate bound\n");  
  
  if (in == NULL)
    reportf("ERROR! Could not open file: %s\n", input_file), exit(1);
  parse_WPMS(in,S,top,sc,hc);
  bool sat = S.solve();
  for(int i=sc.size()-1; i>0; i--){
    for(int j=0; j<i; j++){
      if(sc[j]->weight < sc[j+1]->weight){
        WeightedClause* tmp = sc[j]; sc[j] = sc[j+1]; sc[j+1] = tmp;	
      }
    }
  }

  int weight_sum=0;
  for(int i=0; i<sc.size(); i++) { weight_sum += sc[i]->weight;}
  reportf("sum of the soft clauses weight:%d\n",weight_sum);
  for(int i=0; i<hc.size(); i++) S.addClause(hc[i]->clause);  

  reportf("hard clauses only.\n");

  if(S.solve()){
    eval = eval_model(S,sc);
    reportf("\bSATISFIABLE\b\n");
    reportf("optimum <= %d\n",weight_sum - eval);
  }
  else {    
    reportf("\bUNSAT\b\n");
    reportf("Can\'t solve hard clauses\n");
    exit(0);
  }
    
  for(int i=0; i<sc.size(); i++) {
    reportf("--------------------------\n");
    reportf("Add soft clause.\n");
    S.addClause(sc[i]->clause);
    if(S.solve()){
      eval = eval_model(S,sc);
      reportf("\bSATISFIABLE\b\n");
      reportf("optimum <= %d\n",weight_sum - eval);
    }      
    else{
      reportf("\bUNSAT\b\n");
      reportf("optimum <= %d\n",weight_sum - eval);
      reportf("--------------------------\n");
      break;
    }
  }
  return weight_sum - eval;
}
