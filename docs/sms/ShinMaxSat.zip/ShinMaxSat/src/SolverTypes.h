/***********************************************************************************[SolverTypes.h]
Copyright (c) 2005-2010, Niklas Een, Niklas Sorensson

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/

/**************************************************************************************************

Contains the solver specific types: Var, Lit, Clause

**************************************************************************************************/


#ifndef SolverTypes_h
#define SolverTypes_h


//#include "mtl/IntTypes.h"

//#include "Int.h"


//=================================================================================================
// Variables, literals:


// NOTE! Variables are just integers. No abstraction here. They should be chosen from 0..N,
// so that they can be used as array indices.

typedef int Var;
#define var_Undef (-1)

  struct Lit {
    int     x;

    // Use this as a constructor:
    friend Lit mkLit(Var var, bool sign = false);

    bool operator == (Lit p) const { return x == p.x; }
    bool operator != (Lit p) const { return x != p.x; }
    bool operator <  (Lit p) const { return x < p.x;  } // '<' makes p, ~p adjacent in the ordering.
  };


  inline  Lit  mkLit     (Var var, bool sign) { Lit p; p.x = var + var + (int)sign; return p; }
  inline  Lit  operator ~(Lit p)              { Lit q; q.x = p.x ^ 1; return q; }
  inline  Lit  operator ^(Lit p, bool b)      { Lit q; q.x = p.x ^ (unsigned int)b; return q; }
  inline  bool sign      (Lit p)              { return p.x & 1; }
  inline  int  var       (Lit p)              { return p.x >> 1; }

  // Mapping Literals to and from compact integers suitable for array indexing:
  inline  int  toInt     (Var v)              { return v; }
  inline  int  toInt     (Lit p)              { return p.x; }
  inline  Lit  toLit     (int i)              { Lit p; p.x = i; return p; }

  //const Lit lit_Undef = mkLit(var_Undef, false);  // }- Useful special constants.
  //const Lit lit_Error = mkLit(var_Undef, true );  // }

  const Lit lit_Undef = { -2 };  // }- Useful special constants.
  const Lit lit_Error = { -1 };  // }



//static inline uint64 abstLit(Lit p) { return ((uint64)1) << (index(p) & 63); }

//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

#define L_LIT    "%sx%d"
#define L_lit(p) sign(p)?"~":"", var(p)

/* //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

/* struct BasicSolverStats { */
/*     int64   starts, decisions, propagations, inspects, conflicts; */
/*     BasicSolverStats(void) : starts(0), decisions(0), propagations(0), inspects(0), conflicts(0) { } */
/* }; */

//=================================================================================================
#endif
