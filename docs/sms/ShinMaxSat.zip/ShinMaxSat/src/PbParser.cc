/**************************************************************************************[PbParser.C]
Copyright (c) 2005-2010, Niklas Een, Niklas Sorensson

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/

#include "PbParser.h"
#include "File.h"
#include "Debug.h"

class FileBuffer {
    File    in;
    int     next;
public:
    int     line;
    FileBuffer(cchar* input_file) : in(input_file, "rb") {
        if (in.null()) reportf("ERROR! Could not open file for reading: %s\n", input_file), exit(0);
        next = in.getCharQ();
        line = 1; }
   ~FileBuffer() {}
    int  operator *  () { return next; }
    void operator ++ () { if (next == '\n') line++; next = in.getCharQ(); }
};


class StringBuffer {
    cchar*  ptr;
    cchar*  last;
public:
    int     line;
    StringBuffer(cchar* text)           { ptr = text; last = ptr + strlen(text); line = 1; }
    StringBuffer(cchar* text, int size) { ptr = text; last = ptr + size; line = 1; }
   ~StringBuffer() {}
    int  operator *  () { return (ptr >= last) ? EOF : *ptr; }
    void operator ++ () { if (*ptr == '\n') line++; ++ptr; }
};


template<class B>
static void skipWhitespace(B& in) {     // not including newline
    while (*in == ' ' || *in == '\t')
        ++in; }

template<class B>
static void skipLine(B& in) {
    for (;;){
        if (*in == EOF) return;
        if (*in == '\n') { ++in; return; }
        ++in; } }

template<class B>
static void skipComments(B& in) {      // skip comment and empty lines (assuming we are at beginning of line)
    while (*in == '*' || *in == '\n') skipLine(in); }

template<class B>
static bool skipEndOfLine(B& in) {     // skip newline AND trailing comment/empty lines
    if (*in == '\n' || *in == '\r') ++in;
    else             return false;
    skipComments(in);
    return true; }

template<class B>
static bool skipText(B& in, cchar* text) {
    while (*text != 0){
        if (*in != *text) return false;
        ++in, ++text; }
    return true; }

template<class B>
static Int parseInt(B& in) {
    Int     val(0);
    bool    neg = false;    
    skipWhitespace(in);
    if      (*in == '-') neg = true, ++in;
    else if (*in == '+') ++in;
    skipWhitespace(in);     // BE NICE: allow "- 3" and "+  4" etc.
    if (*in < '0' || *in > '9') 
      throw nsprintf("Expected digit, not: %c", *in);
     while (*in >= '0' && *in <= '9'){
      #ifdef NO_GMP
        val *= 2; 
        if (val < 0 || val > Int(9223372036854775807LL >> 20)) throw xstrdup("Integer overflow. Use BigNum-version.");      // (20 extra bits should be enough...)
        val *= 5;
      #else
        val *= 10;
      #endif
        val += (*in - '0');
         ++in; }
    return neg ? -val : val; }


template<class B>
static bool match(B& in, char* str) {
  for (; *str != 0; ++str, ++in)
    if (*str != *in)
      return false;
  return true;
}

template<class B,class S>
static void readClause(B& in,S& solver,int top,vec<Lit>& ps,vec<Int>& Cs,vec<Lit>& b_ps,vec<Int>& b_Cs) { // koshi 10.01.04
  
  Int weight=-1,parsed_lit,rhs = 1;
  char block[256];
// for(int i=0; i<solver.constrs.size(); i++){
//      dump(solver.constrs[i]);    
//    printf("\n");
//    }
// reportf("aaaa%c",*in);
  if(opt_mstype == MS){
    weight = 1;
    sprintf(block,"b%d",b_ps.size()+1);
  }
  else if(opt_mstype == WMS){
    weight = parseInt(in);
    sprintf(block,"b%d",b_ps.size()+1);
  }
  else if(opt_mstype == PMS || opt_mstype == WPMS){
    weight = parseInt(in);
    if(weight >= top) weight = -1;
    else sprintf(block,"b%d",b_ps.size()+1);
  }
  //  dump(weight);
  ps.clear();
  Cs.clear();
  if(weight != -1){
    ps.push(mkLit(solver.getVar(block)));
    Cs.push(weight);
    b_ps.push(mkLit(solver.getVar(block)));
    b_Cs.push(weight);
  }
  
  for(;;){
    parsed_lit = parseInt(in);
    if (parsed_lit == 0) break;
    if (parsed_lit < 0) {
      rhs -= 1;
      parsed_lit *= -1;
      Cs.push(-1);
    }
    else{
      Cs.push(1);
    }
    ps.push(mkLit(solver.getVar(toString(parsed_lit))));
  }
  
  solver.addConstr(ps,Cs,rhs,1);
  // dump(solver.constrs[0]);
}

template<class B, class S>
static void parse_MS_main(B& in,S& solver) {
  int vars,clauses,top;
  vec<Lit> ps,b_ps;
  vec<Int> Cs,b_Cs;
  for (;;){
    skipWhitespace(in);
    if (*in == EOF)
      break;
    else if (*in == 'p'){
      if (match(in, "p wcnf")){
	vars    = toint(parseInt(in));
	clauses = toint(parseInt(in));
	if(*in == '\n') {
	  opt_mstype = WMS;
	}
	else{
	  opt_mstype = WPMS;
	  top = toint(parseInt(in));
	}	
	skipLine(in);
      }
      else if(match(in, "cnf")){
	vars    = toint(parseInt(in));
	clauses = toint(parseInt(in));
	opt_mstype = MS;
	skipLine(in);
      }
      else{
	reportf("PARSE ERROR! Unexpected char: %c\n", *in), exit(3);
      }      
    }
    else if (*in == 'c' || *in == 'p') skipLine(in);
    else {
      readClause(in,solver,top,ps,Cs,b_ps,b_Cs);
      skipEndOfLine(in);
    };
  }
  solver.addGoal(b_ps,b_Cs);
}


void parse_MS_file(cchar* filename, PbSolver& solver) {
  FileBuffer buf(filename);
  parse_MS_main(buf,solver);
  
    }
