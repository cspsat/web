/****************************************************************************************[Solver.h]
Copyright (c) 2005-2010, Niklas Een, Niklas Sorensson

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/

#ifndef Solver_h
#define Solver_h

#include "SolverTypes.h"
#include "MiniSat2.2.0.h"
#include "utils/System.h"

//=================================================================================================

class Solver {
  //    MiniSat ::Solver*   minisat;
     Minisat2 ::Solver*  minisat;
 public: 
     bool&             ok_ref     () { return minisat->ok;} 
     vec<lbool>&         assigns_ref() { return minisat->assigns;}
     vec<Lit>&         trail_ref  () { return minisat->trail;}
     //     BasicSolverStats& stats_ref  () { return (BasicSolverStats&)minisat->stats; }

     void setVerbosity(int level) { minisat->verbosity = level;}

     Var         newVar         (bool dvar = true)   { return minisat->newVar(dvar);}
     bool        addClause      (const vec<Lit>& ps) { return minisat->addClause(ps); }
     bool        addUnit        (Lit p)              { return minisat->addClause(p); }
/*     //    void        freeze         (Var x)              { if (minisat == NULL) satelite->freeze(x); } */
//     void        suggestPolarity(Var x, lbool value) { minisat->polarity_sug[x] = toInt(value);} 
     bool        solve     (const vec<Lit>& assumps) { return minisat->solve(assumps);}
     bool        solve          ()                   { vec<Lit> tmp; return solve(tmp); }
     vec<lbool>& model          ()                   { return minisat->model;}
     bool        varElimed      (Var x)              { return false;} 
     bool        okay           ()                   { return minisat->okay();}
     int         nVars          ()                   { return minisat->nVars(); }
	    //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

  Solver(bool use_minisat2) : minisat(new Minisat2 ::Solver()) {}

     void printStats(void)
{
    double cpu_time = cpuTime();
    double mem_used = Minisat2::memUsedPeak();
    reportf("restarts              : %"PRIu64"\n", minisat->starts);
    reportf("conflicts             : %-12"PRIu64"   (%.0f /sec)\n", minisat->conflicts   , minisat->conflicts   /cpu_time);
    reportf("decisions             : %-12"PRIu64"   (%4.2f %% random) (%.0f /sec)\n", minisat->decisions, (float)minisat->rnd_decisions*100 / (float)minisat->decisions, minisat->decisions   /cpu_time);
    reportf("propagations          : %-12"PRIu64"   (%.0f /sec)\n", minisat->propagations, minisat->propagations/cpu_time);
    reportf("conflict literals     : %-12"PRIu64"   (%4.2f %% deleted)\n", minisat->tot_literals, (minisat->max_literals - minisat->tot_literals)*100 / (double)minisat->max_literals);
    if (mem_used != 0) reportf("Memory used           : %.2f MB\n", mem_used);
    reportf("CPU time              : %g s\n", cpu_time);
}

     
 }; 


//=================================================================================================
#endif
